The client is supposed to emulate a device that records temperature and heartrate data of the farmworkers.
The server collects this information, logs it in logs.txt and is supposed to send it to a javascript file which would be posted on an html website that crew leaders could access.
We could not implement the javascript file correctly.
Currently the server and client are meant to run on the same computer because we are on the same router and can not send messages to each other via our computers.
The html website is available in zip format.